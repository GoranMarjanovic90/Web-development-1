function myFunction() {
document.getElementById("fname").value = "Goran";
document.getElementById("lname").value = "Marjanovic";
document.getElementById("age").value = "34";
    document.getElementById("demo").innerHTML = "<p>Mitt namn är Goran Marjanovic och jag är 34 år gammal</p>";
}